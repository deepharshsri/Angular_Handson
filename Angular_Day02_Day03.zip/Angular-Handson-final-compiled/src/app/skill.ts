export interface Skills{
    id:number;
    name:String;
}