import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-employee-reactive',
  templateUrl: './edit-employee-reactive.component.html',
  styleUrls: ['./edit-employee-reactive.component.css']
})
export class EditEmployeeReactiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
